[Gamera Manifesto](http://gameramanifesto.org/)
================

A brutal manifesto for regular humans with colossal goals. Visit at http://gameramanifesto.org/.

